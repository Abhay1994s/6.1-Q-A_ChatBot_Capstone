# -*- coding: utf-8 -*-
"""
Created on Mon May  7 14:24:04 2018

@author: AB356917
"""
from watson_developer_cloud import DiscoveryV1
import pandas as pd

username = "624f1183-b6fd-4d3f-89fb-25d7bacd62ea"
password = "qpBnfnwgFvFl"
environment_id = "21b48972-46e5-401d-a3b8-100724ce94e9"
collection_id = "79c84b28-a8b4-48b8-b152-a1aed08c8480"
discovery = DiscoveryV1(username= username, password= password, version="2017-11-07")


def build_a_data_frame_of_train_data():
    list_of_lists= []
    search_response = discovery.query(environment_id,collection_id,count = 1000,highlight = "True")
    for jsons in search_response["results"]:
        list_of_attributes = []
        total_sentiment_around_entities = 0
        length_of_review = len(jsons["text"])
        list_of_attributes.append(jsons["Title"])
        for entities in jsons["enriched_text"]["entities"]:
            if entities["type"] == "Person":
                total_sentiment_around_entities += entities["sentiment"]["score"]
        print(total_sentiment_around_entities,jsons["Title"],jsons["Stars"])
        total_emotion = jsons["enriched_text"]["emotion"]["document"]["emotion"]["disgust"]+jsons["enriched_text"]["emotion"]["document"]["emotion"]["joy"]+jsons["enriched_text"]["emotion"]["document"]["emotion"]["anger"]+jsons["enriched_text"]["emotion"]["document"]["emotion"]["fear"]+jsons["enriched_text"]["emotion"]["document"]["emotion"]["sadness"]
        list_of_attributes.append(total_sentiment_around_entities)
        list_of_attributes.append(jsons["enriched_text"]["sentiment"]["document"]["score"])
        list_of_attributes.append(jsons["enriched_text"]["emotion"]["document"]["emotion"]["disgust"])
        list_of_attributes.append(jsons["enriched_text"]["emotion"]["document"]["emotion"]["joy"])
        list_of_attributes.append(jsons["enriched_text"]["emotion"]["document"]["emotion"]["anger"])
        list_of_attributes.append(jsons["enriched_text"]["emotion"]["document"]["emotion"]["fear"])
        list_of_attributes.append(jsons["enriched_text"]["emotion"]["document"]["emotion"]["sadness"])
        list_of_attributes.append(length_of_review)
        list_of_attributes.append(total_emotion)
        list_of_attributes.append(jsons["Stars"])  
        list_of_lists.append(list_of_attributes)  
  
    train_data_for_model  = pd.DataFrame()(data =list_of_lists, columns = ['Title','total_sentiment_around_entities','document_sentiment','disgust','joy','anger','fear','sadness','length_of_review','total_emotion','Stars'])
    print(train_data_for_model)
    train_data_for_model.to_csv("data.csv")