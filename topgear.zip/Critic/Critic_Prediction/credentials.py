username = "624f1183-b6fd-4d3f-89fb-25d7bacd62ea"
password = "qpBnfnwgFvFl"
environment_id= "21b48972-46e5-401d-a3b8-100724ce94e9"
collection_id= "abd7dbf7-b7d2-46dc-be0f-3b463b4b7559"

training_file_path = "./train.json"
test_file_path = "./test.json"
