import re
import json
from watson_developer_cloud import DiscoveryV1
from credentials import username,password,environment_id,collection_id,test_file_path

discovery = DiscoveryV1(username= username, password= password, version="2017-11-07") # initializing watson discovery object with the desired credentials

def critic_predict(review, rating):
    '''preprocessing of the review to remove special character words and take the last 4-5 lines of review
           because in the review analysis first part is the details of the movie and in the second half main
           review is present'''
    stop_words = ['advertisement','he ','she ','she s','can t','doesn t','it s','it ','he s',' the','him ','her ','don t','con', 'wherein', 'without', 'see', 'at', 'ltd', 'those', 'together', 'give', 'fire', 'eg', 'doing', 'always', 'whither', 'along', 'whose', 'was', 'rather', 'more', 'well', 'under', 'say', 'whole', 'me', 'full', 'during', 'same', 'been', 'am', 'whereafter', 'yours', 'then', 'us', 'it', 'to', 'please', 'latterly', 'would', 'made', 'for', 'again', 'may', 'whom', 'should', 'whence', 'twenty', 'out', 'everyone', 'don', 'them', 'empty', 'found', 'will', 'anyway', 'fify', 'kg', 'everything', 'nor', 'bill', 'seems', 'forty', 'something', 'across', 'sincere', 'third', 'after', 'whoever', 'might', 'how', 'nothing', 'most', 'any', 're', 'so', 'using', 'formerly', 'much', 'when', 'many', 'none', 'perhaps', 'before', 'while', 'thereafter', 'which', 'seemed', 'unless', 'into', 'upon', 'therefore', 'why', 'your', 'he', 'further', 'onto', 'however', 'toward', 'they', 'that', 'thereupon', 'within', 'him', 'de', 'still', 'by', 'ever', 'or', 'has', 'former', 'ie', 'over', 'does', 'than', 'both', 'beyond', 'in', 'until', 'though', 'now', 'take', 'above', 'about', 'beforehand', 'had', 'un', 'on', 'already', 'couldnt', 'and', 'namely', 'herein', 'fifty', 'yet', 'what', 'km', 'few', 'besides', 'name', 'where', 'quite', 'put', 'five', 'move', 'least', 'all', 'detail', 'four', 'become', 'show', 'due', 'did', 'various', 'everywhere', 'can', 'seem', 'do', 'amoungst', 'call', 'were', 'keep', 'neither', 'elsewhere', 'sometimes', 'every', 'two', 'get', 'else', 'eleven', 'whatever', 'who', 'have', 'becomes', 'thru', 'too', 'three', 'nevertheless', 'whereupon', 'meanwhile', 'ca', 'except', 'seeming', 'moreover', 'each', 'front', 'not', 'someone', 'thence', 'these', 'also', 'behind', 'just', 'be', 'through', 'thus', 'used', 'part', 'mill', 'indeed', 'therein', 'around', 'computer', 'whether', 'another', 'never', 'an', 'per', 'a', 'such', 'back', 'ten', 'thick', 'sixty', 'one', 'cant', 'here', 'his', 'other', 'whenever', 'i', 'inc', 'became', 'hence', 'because', 'anyone', 'serious', 'myself', 'this', 'didn', 'cry', 'somewhere', 'done', 'herself', 'fill', 'hundred', 'mostly', 'enough', 'the', 'etc', 'of', 'nobody', 'hasnt', 'no', 'since', 'her', 'almost', 'amount', 'fifteen', 'eight', 'afterwards', 'less', 'hereby', 'if', 'itself', 'own', 'she', 'with', 'go', 'becoming', 'even', 'wherever', 'first', 'once', 'our', 'nowhere', 'anyhow', 'whereas', 'describe', 'amongst', 'below', 'very', 'co', 'towards', 'their', 'ourselves', 'throughout', 'anywhere', 'next', 'hers', 'among', 'bottom', 'its', 'must', 'between', 'is', 'find', 'himself', 'anything', 'via', 'down', 'somehow', 'but', 'yourselves', 'interest', 'otherwise', 'as', 'thin', 'cannot', 'ours', 'although', 'doesn', 'sometime', 'often', 'others', 'being', 'really', 'either', 'hereupon', 'whereby', 'some', 'six', 'side', 'alone', 'thereby', 'you', 'hereafter', 'regarding', 'off', 'we', 'could', 'there', 'system', 'mine', 'last', 'beside', 'twelve', 'from', 'top', 'make', 'up', 'themselves', 'several', 'against', 'nine', 'noone', 'my', 'are', 'latter', 'yourself', 'only']

    processed_review = [re.sub(r'[^\w\s]',' ',word) for word in review.split()] # removing special characters from each word of review and taking only the last 50 words
    processed_review = [word for word in processed_review if word != '' and word.lower() not in stop_words] # removing empty words i.e null strings after cleaning
    if len(processed_review)>50:
        processed_review = " ".join(processed_review[-50:]) # converting list of last 50 words into string
    else:
        processed_review = " ".join(processed_review)
    # quering review in watson discovery
    review_analysis = discovery.query(environment_id=environment_id, collection_id=collection_id,
                                          query=processed_review, count=3)
    critic = ''
    output_1 = review_analysis['results'][0]['extracted_metadata']['filename']
    critic = output_1.replace('.json','').title()

    if('Negative' in critic):
        critic = critic.replace('_Negative','')
    else:
        critic = critic.replace('_Positive','')
    return critic
    
def Test_Model(test_file_path):
    print("TESTING STARTED")
    with open(test_file_path,'r',encoding='utf-8', errors='ignore') as file:
        d= json.loads("[%s]"%file.read().strip().replace('}\n{','},{'))
        file.close()
    result = []
#    actual = []
    output = ''
    for i in range(len(d)):
        output = critic_predict(d[i]['Review'], d[i]['Stars'])
        result.append(output)
        print("Critic for Review "+str(i)+" is : ",result[i])
#        actual.append(d[i]['Critic'])
    with open('./Testing_Output/TESTING_RESULT.txt','w',encoding='utf-8') as cr:
        for i in result:
            cr.write(str(i))
            cr.write('\n')
        cr.close()
    return result

result = Test_Model(test_file_path)

#def accuracy(result,actual):
#    count =0
#    for i in range(len(result)):
#        if result==actual:
#            count+=1
#    return count/len(result)
#acc= accuracy(result,actual)
#print("ACCURACY IS:",acc)