import json
import pandas as pd
import re
from watson_developer_cloud import DiscoveryV1
from credentials import username,password,environment_id,collection_id,training_file_path

discovery = DiscoveryV1(username= username, password= password, version="2017-11-07")

def Training_Model(training_file_path):
    with open(training_file_path,'r',encoding='utf-8', errors='ignore') as file:
        d= json.loads("[%s]"%file.read().strip().replace('}\n{','},{'))
        file.close()
    print("TRAINING STARTED")  
    # Creating a dataframe of Training sample    
    df = pd.DataFrame(d)
    
    # Seprating movies based on Critic
    Alpha_df = df[df['Critic']=='Alpha'].sort_values('Stars',ascending=False)
    Beta_df = df[df['Critic']=='Beta'].sort_values('Stars',ascending=False)
    Gamma_df = df[df['Critic']=='Gamma'].sort_values('Stars',ascending=False)
    Delta_df = df[df['Critic']=='Delta'].sort_values('Stars',ascending=False)
    
    # Critics positive and negative review collection
    Alpha_df_pos_rev = ''.join(Alpha_df[Alpha_df['Stars']>=3.0]['Review'])
    Alpha_df_neg_rev = ''.join(Alpha_df[Alpha_df['Stars']<3.0]['Review'])
    Beta_df_pos_rev = ''.join(Beta_df[Beta_df['Stars']>=3.0]['Review'])
    Beta_df_neg_rev = ''.join(Beta_df[Beta_df['Stars']<3.0]['Review'])
    Gamma_df_pos_rev = ''.join(Gamma_df[Gamma_df['Stars']>=3.0]['Review'])
    Gamma_df_neg_rev = ''.join(Gamma_df[Gamma_df['Stars']<3.0]['Review'])
    Delta_df_pos_rev = ''.join(Delta_df[Delta_df['Stars']>=3.0]['Review'])
    Delta_df_neg_rev = ''.join(Delta_df[Delta_df['Stars']<3.0]['Review'])
    
    # Preprocessing of Reviews
    Alpha_df_pos_rev = [re.sub(r'[^\w\s]',' ',word) for word in Alpha_df_pos_rev.split()]
    Alpha_df_pos_rev = [word for word in Alpha_df_pos_rev if word != '']

    Alpha_df_neg_rev = [re.sub(r'[^\w\s]',' ',word) for word in Alpha_df_neg_rev.split()]
    Alpha_df_neg_rev = [word for word in Alpha_df_neg_rev if word != '']

    Beta_df_pos_rev = [re.sub(r'[^\w\s]',' ',word) for word in Beta_df_pos_rev.split()]
    Beta_df_pos_rev = [word for word in Beta_df_pos_rev if word != '']

    Beta_df_neg_rev = [re.sub(r'[^\w\s]',' ',word) for word in Beta_df_neg_rev.split()]
    Beta_df_neg_rev = [word for word in Beta_df_neg_rev if word != '']

    Gamma_df_pos_rev = [re.sub(r'[^\w\s]',' ',word) for word in Gamma_df_pos_rev.split()]
    Gamma_df_pos_rev = [word for word in Gamma_df_pos_rev if word != '']

    Gamma_df_neg_rev = [re.sub(r'[^\w\s]',' ',word) for word in Gamma_df_neg_rev.split()]
    Gamma_df_neg_rev = [word for word in Gamma_df_neg_rev if word != '']

    Delta_df_pos_rev = [re.sub(r'[^\w\s]',' ',word) for word in Delta_df_pos_rev.split()]
    Delta_df_pos_rev = [word for word in Delta_df_pos_rev if word != '']

    Delta_df_neg_rev = [re.sub(r'[^\w\s]',' ',word) for word in Delta_df_neg_rev.split()]
    Delta_df_neg_rev = [word for word in Delta_df_neg_rev if word != '']
    
    # JSON Files of Critic postive and negative review uploaded to Watson Discovery
    with open('./Watson_Training_Data/Alpha_positive.json','w',encoding='utf-8') as f:
        f.write(json.dumps({"text":" ".join(Alpha_df_pos_rev)}))
        f.close()
    with open("./Watson_Training_Data/Alpha_positive.json",'r') as file:
        print("Alpha_positive.json Uploaded")
        response_upload = discovery.add_document(environment_id,collection_id, file=file)
        print(response_upload)
        
    with open('./Watson_Training_Data/Alpha_negative.json','w',encoding='utf-8') as f:
        f.write(json.dumps({"text":" ".join(Alpha_df_neg_rev)}))
        f.close()
    with open("./Watson_Training_Data/Alpha_negative.json",'r') as file:
        print("Alpha_negative.json Uploaded")
        response_upload = discovery.add_document(environment_id,collection_id, file=file)
        print(response_upload)
        
    with open('./Watson_Training_Data/Beta_positive.json','w',encoding='utf-8') as f:
        f.write(json.dumps({"text":" ".join(Beta_df_pos_rev)}))
        f.close()
    with open("./Watson_Training_Data/Beta_positive.json",'r') as file:
        print("Beta_positive.json Uploaded")
        response_upload = discovery.add_document(environment_id,collection_id, file=file)
        print(response_upload)
        
    with open('./Watson_Training_Data/Beta_negative.json','w',encoding='utf-8') as f:
        f.write(json.dumps({"text":" ".join(Beta_df_neg_rev)}))
        f.close()
    with open("./Watson_Training_Data/Beta_negative.json",'r') as file:
        print("Beta_negative.json Uploaded")
        response_upload = discovery.add_document(environment_id,collection_id, file=file)
        print(response_upload)
        
    with open('./Watson_Training_Data/Gamma_positive.json','w',encoding='utf-8') as f:
        f.write(json.dumps({"text":" ".join(Gamma_df_pos_rev)}))
        f.close()
    with open("./Watson_Training_Data/Gamma_positive.json",'r') as file:
        print("Gamma_positive.json Uploaded")
        response_upload = discovery.add_document(environment_id,collection_id, file=file)
        print(response_upload)
    
    with open('./Watson_Training_Data/Gamma_negative.json','w',encoding='utf-8') as f:
        f.write(json.dumps({"text":" ".join(Gamma_df_neg_rev)}))
        f.close()
    with open("./Watson_Training_Data/Gamma_negative.json",'r') as file:
        print("Gamma_negative.json Uploaded")
        response_upload = discovery.add_document(environment_id,collection_id, file=file)
        print(response_upload)
        
    with open('./Watson_Training_Data/Delta_positive.json','w',encoding='utf-8') as f:
        f.write(json.dumps({"text":" ".join(Delta_df_pos_rev)}))
        f.close()
    with open("./Watson_Training_Data/Delta_positive.json",'r') as file:
        print("Delta_positive.json Uploaded")
        response_upload = discovery.add_document(environment_id,collection_id, file=file)
        print(response_upload)
        
    with open('./Watson_Training_Data/Delta_negative.json','w',encoding='utf-8') as f:
        f.write(json.dumps({"text":" ".join(Delta_df_neg_rev)}))
        f.close()
    with open("./Watson_Training_Data/Delta_negative.json",'r') as file:
        print("Delta_negative.json Uploaded")
        response_upload = discovery.add_document(environment_id,collection_id, file=file)
        print(response_upload)
    print("Training Completed")
        
Training_Model(training_file_path)