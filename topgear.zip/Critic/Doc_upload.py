# -*- coding: utf-8 -*-
"""
Created on Mon May  7 17:19:23 2018

@author: AB356917
"""
from watson_developer_cloud import DiscoveryV1

username = "624f1183-b6fd-4d3f-89fb-25d7bacd62ea"
password = "qpBnfnwgFvFl"
environment_id = "21b48972-46e5-401d-a3b8-100724ce94e9"
collection_id = "3297ddcb-22bf-4b19-bb1a-f7a93f4aec87"

discovery = DiscoveryV1(username= username, password= password, version="2017-11-07")


def file_upload():
    counter = 0
    input_data = open('train.json','r')
    for index_file,content in enumerate(input_data):
        content = content.replace("Review","text")
        with open("processed.json", 'w') as f:
            f.write(str({}))
        with open("processed.json", 'w') as f:
            f.write(content)
  
        with open("processed.json",'r') as file:
            print("processed_Train",counter," uploaded")
            response_upload = discovery.add_document(environment_id,collection_id, file=file)
            print(response_upload)
            counter += 1
#            if(counter > 100):
#                break
#    discovery_response = discovery.query(environment_id,collection_id,count = 1000,highlight = "True") 
#    return discovery_response
file_upload()