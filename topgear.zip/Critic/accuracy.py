# -*- coding: utf-8 -*-
"""
Created on Sun May  6 16:37:21 2018

@author: AB356917
"""
import json
from critic import critic_predict

with open('C:/Users/ab356917/Downloads/topgear/Critic/train.json','r',encoding='utf-8', errors='ignore') as file:
    d= json.loads("[%s]"%file.read().strip().replace('\n',','))
    file.close()
count = 0

for i in range(len(d)):
    print("RUNNING",i)
    if critic_predict(d[i]['Review'], d[i]['Stars'])==d[i]['Critic']:
        count+=1
print((count/len(d))*100)